<div class="container-fluid">
    <div class="row">
      <div class="container">
        <div class="col-md-12 payment_msg">
          <center><h1>Payment Error</h1>
            <p class="payment_success">Your payment was unsuccessful. Please try again. If you continue to receive an error message please contact us.</p>
            <img src="<?php  echo base_url(); ?>assets/front/images/cancel.png">
          </center>
        </div>
      </div>

	</div>
</div>
<style>
#stickfooter{
  position: fixed;
  width: 100%;
  bottom: 0px;
}
.payment_msg{
  margin-top: 60px;
}
.payment_success{
  width: 600px;
}
</style>
