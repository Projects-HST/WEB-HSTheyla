
  <section class="privacy">
<div class="container">
  <div class="col-md-12">
    <p style="color:#000;">
                      <b>Acceptance of Terms</b><br>
                      The HeylaApp is one stop platform for all your event needs which is owned and operated by PalPro Technologies Pvt. Ltd., with its registered office at 21, Vaigai North Bank Road, Alwarpuram Thiruvenkatapuram, Madurai TN 625002.
                      Through our platform, mobile apps and website; Heyla shall enable users to view and share the events and book tickets for events in and around Chennai, Coimbatore, Madurai and Pondicherry. This User Agreement (Agreement) sets out the terms and conditions on which Heyla shall provide the services to the User through Website and App.
                      The usage of the Website/App is offered to the User conditioned on acceptance without modification of all the terms, conditions and notices contained in this Agreement, as may be posted on the Website/App from time to time. For the removal of doubts, it is clarified that use of the Website/App by the User constitutes an acknowledgement and acceptance by the User of this Agreement.
                      Heyla reserves the right to change the terms & conditions and notices under which the Services are offered through the Website/ App, including but not limited to the charges for the Services provided through the Website/App. The User shall be responsible for regularly reviewing these terms and conditions.
                    <br><br><b>  Privacy Policy</b><br>
                      The User hereby consents, expresses and agrees that he/she has read and fully understands the Privacy Policy of Helya in respect to the website/app. The User further consents that the terms and contents of such Privacy Policy are acceptable to him/her.

                      <br><br><b>Services</b><br>
                      Users are entitled to use the Services including viewing,  and sharing of events. Heyla also lets users book their tickets or register for events through the app. The company reserves the right to modify the nature of their services.
                      If the users are booking their tickets through our platform, they hereby consent, express and agree that they have read and fully understands the Pricing Policy of Helya in respect to the website/app. The User further consents that the terms of such Pricing Policy are acceptable to him/her.

                     <br> <br><b>Restrictions on use</b><br>
                      Your use of the website/app is restricted to viewing information of events, booking tickets, giving suggestions or raising queries or complaints. To protect our website, app and other users, we reserve all the rights to delete any content from the website/app. We also reserve the right to restrict the access of the website/app to certain users.
                      <br><br><b>Changes on Terms & Conditions</b><br>
                      This terms & conditions was last updated on 29.03.2017. From time to time we may change or make additions to our terms & Condition. We will notify you of any material changes to this policy as required by law. We will also post an updated copy on our website and during app updates.
                      Contact Us
                      If there is any query regarding the terms & conditions, you may contact us.
    </p>
  </div>
</div>
</section>
