<div class="container-fluid">
    <div class="row">
      <div class="container">
        <div class="col-md-12 payment_msg">
          <center><h1>Thank you.</h1>
            <p class="payment_success">Your payment has been received successfully. For other details regarding the payment visit your booking details page. We have sent an email to you with order details. If you have queries contact us.</p>
            <img src="<?php  echo base_url(); ?>assets/front/images/success.png">
          </center>
        </div>
      </div>

	</div>
</div>
<style>
#stickfooter{
  position: fixed;
  width: 100%;
  bottom: 0px;
}
.payment_msg{
  margin-top: 60px;
}
.payment_success{
  width: 600px;
}
</style>
