<div class="container-fluid">
    <div class="row">
      <div class="container">
        <div class="col-md-12 payment_msg">
          <center>
            <img src="<?php  echo base_url(); ?>assets/front/images/cancel.png" style="margin-bottom:15px;">
            <h1>Payment Error</h1>
            <p class="payment_success">Your payment was unsuccessful. Please try again. If you continue to receive an error message please contact us.</p>

          </center>
        </div>
      </div>

	</div>
</div>
<style>

.payment_msg{
  margin-top: 150px;
  margin-bottom: 150px;
}
.payment_success{
  width: 600px;
  font-size: 18px;
}
</style>
