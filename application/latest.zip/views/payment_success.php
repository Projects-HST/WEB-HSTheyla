<div class="container-fluid">
    <div class="row">
      <div class="container">
        <div class="col-md-12 payment_msg">

              <center><img src="<?php  echo base_url(); ?>assets/front/images/success.png" style="margin-bottom:15px;">
                <br>
            <h1>Thank you.</h1>
            <p class="payment_success">Your payment has been received successfully. For other details regarding the payment visit your booking details page. We have sent an email to you with order details. If you have queries contact us.</p>

          </center>
        </div>
      </div>

	</div>
</div>
<style>
.payment_msg{
  margin-top: 150px;
  margin-bottom: 150px;
}
.payment_success{
  width: 600px;
    font-size: 18px;
}
</style>
