
<div class="container-fluid order_summary_page">
  <div class="order_table">
<div class="container summary_tab">

<div class="col-md-12 top_heading_box">
  <p class="text-center summary_title"> Heyla  Order summary</p>
</div>
<div class="col-md-12 summary_card">
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-5"><p class="summary_label summary_text">Order id </p></div>
    <div class="col-md-1"><p class="summary_text">:</p></div>
    <div class="col-md-6"><p class="summary_text">123456</p></div>
  </div>
  <div class="row">
    <div class="col-md-12 text-center" style="margin-top:20px;">  <p><a href="" class=" book_tickets" style="padding-left:30px;padding-right:30px;margin:10px 40px 40px 10px;">Pay Now</a></p></div>

  </div>


</div>
</div>
</div>
</div>
